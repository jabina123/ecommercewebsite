const Cart = () => {
    return <h2>Cart Page</h2>;
  };
  
  export default Cart;
  