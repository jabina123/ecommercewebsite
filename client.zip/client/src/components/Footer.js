const Footer = () => {
    return (
      <footer className="bg-dark text-light text-center py-3 mt-4">
        <p>© {new Date().getFullYear()} E-Commerce App</p>
      </footer>
    );
  };
  
  export default Footer;
  